import tensorflow as tf
from tensorflow.keras.models import load_model
import numpy as np
import os

def extract_model_data(model):
    layers = [layer for layer in model.layers if 'dense' in layer.name]
    k = len(layers)
    S = [{i for i in range(784)}]
    W = {}
    b = {}
    A = {}

    neuron_count = 784  
    neuron_count1 = 0  
    for i, layer in enumerate(layers):
        W[i+1] = {}
        weights, biases = layer.get_weights()
        b[i+1] = {neuron_count + j: biases[j] for j in range(len(biases))}
        A[i+1] = {neuron_count + j: layer.activation.__name__ for j in range(len(biases))}
        
        new_neurons = [neuron_count + j for j in range(weights.shape[1])]
        S.append(new_neurons)
        
        for input_index in range(weights.shape[0]):
            for output_index in range(weights.shape[1]):
                W[i+1][(input_index + neuron_count1, neuron_count + output_index)] = weights[input_index][output_index]
        
        neuron_count += weights.shape[1]
        neuron_count1 += weights.shape[0]

    return {'k': k, 'S': S, 'W': W, 'b': b, 'A': A}

def lump_neural_network(N):
    k, S, W, b, A = N['k'], N['S'], N['W'], N['b'], N['A']

    # Initialize the equivalence classes for the first layer
    S_prime = {0: {i: [s_i] for i, s_i in enumerate(S[0])}}

    # Initialize the dictionaries for O and W_tilde
    O = {}
    W_tilde = {}

    # Fill O and W_tilde for the first layer
    for Si in S_prime[0]:
        for sj in S[1]:
            O[(Si, sj)] = W[1][(S_prime[0][Si][0], sj)]
            W_tilde[(Si, (sj,))] = W[1][(S_prime[0][Si][0], sj)]

    # Initialize dictionaries for the output
    W_prime = {}
    b_prime = {}
    A_prime = {}

    # Process each layer
    for l in range(1, k):
        S_prime[l] = {}
        Sl = list(S[l])
        b_prime[l] = {}
        A_prime[l] = {}
        W_prime[l] = {}

        while Sl:
            s = Sl.pop(0)
            C = [s]
            b_prime[l][tuple(C)] = b[l][s]
            A_prime[l][tuple(C)] = A[l][s]

            for S_prime_l_minus_1 in S_prime[l - 1]:
                W_prime[l][(S_prime_l_minus_1, tuple(C))] = W_tilde[(S_prime_l_minus_1, (s,))]

            for s_prime in Sl[:]:
                if b[l][s_prime] != 0:
                    rho_s_prime = b[l][s] / b[l][s_prime]
                    consistent = True

                    for S_prime_l_minus_1 in S_prime[l - 1]:
                        #if rho_s_prime * O[(S_prime_l_minus_1, s_prime)] != O[(S_prime_l_minus_1, s)]:
                        if not np.isclose(rho_s_prime * O[(S_prime_l_minus_1, s_prime)], O[(S_prime_l_minus_1, s)], atol=0):
                            consistent = False
                            break

                    if consistent:
                        C.append(s_prime)
                        Sl.remove(s_prime)
                        S_prime[s_prime] = rho_s_prime

            S_prime[l][tuple(C)] = C

        if l + 1 < k: # if not the last layer
            for C in S_prime[l]:
                for s_prime in S[l + 1]:
                    try:
                        O[(C, s_prime)] = sum(W[l + 1].get((r, s_prime), 0) for r in C)
                        W_tilde[(C, (s_prime,))] = sum(S_prime.get(r, 1) * W[l + 1].get((r, s_prime), 0) for r in C)
                    except KeyError as e:
                        print(f"KeyError in layer {l+1}: C={C}, s_prime={s_prime}")
                        print(f"W[{l+1}] keys: {W[l+1].keys()}")
                        print(f"S[{l+1}]: {S[l+1]}")
                        raise e
                    
    return k, S_prime, W_prime, b_prime, A_prime

def process_models(base_path, output_base_path):
    architectures = ['300-100', '500-300', '500-300-100']
    batch_sizes = [80, 120, 160, 200, 240, 280, 320, 360, 400, 440]
    scalers = [1, 3, 5, 7, 9]

    for arch in architectures:
        arch_path = os.path.join(output_base_path, arch)
        os.makedirs(arch_path, exist_ok=True)
        
        for batch in batch_sizes:
            batch_path = os.path.join(arch_path, f'batch{batch}')
            os.makedirs(batch_path, exist_ok=True)
            
            input_batch_path = os.path.join(base_path, arch, f'batch{batch}')
            
            for scaler in scalers:
                model_files = [f for f in os.listdir(input_batch_path) if f.startswith(f'quantized_mnist_scaler{scaler}') and f.endswith('.h5')]
                
                if model_files:
                    model_path = os.path.join(input_batch_path, model_files[0])
                    model = load_model(model_path)
                    
                    N = extract_model_data(model)
                    try:
                        k, S_prime, W_prime, b_prime, A_prime = lump_neural_network(N)
                        
                        output_file = os.path.join(batch_path, f'lumped_neurons_scaler{scaler}.txt')
                        with open(output_file, 'w') as f:
                            f.write(str(S_prime))
                        
                        print(f"Processed: {model_path}")
                        print(f"Output saved to: {output_file}")
                    except Exception as e:
                        print(f"Error processing {model_path}: {str(e)}")
                else:
                    print(f"No model file found for {arch}, batch{batch}, scaler{scaler}")

if __name__ == "__main__":
    base_path = '/Users/gianfranco/Desktop/quantized_neural_networks-master_2/quantized_models'
    output_base_path = '/Users/gianfranco/Desktop/quantized_neural_networks-master_2/reti_lumpate'
    process_models(base_path, output_base_path)