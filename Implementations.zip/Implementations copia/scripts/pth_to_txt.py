import torch
from models import LeNet300_100
import numpy as np
import os

def create_directory(path):
    if not os.path.exists(path):
        os.makedirs(path)

def save_to_txt(data, filename):
    with open(filename, 'w') as f:
        for row in data:
            f.write(' '.join(f'{x:.7e}' for x in row) + '\n')

# Load the pretrained model
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
pytorch_model = LeNet300_100(10, device)

# Load pretrained model in PyTorch
pytorch_model.load_state_dict(torch.load('Archivio/500-300-100/batch440/pretrained_model.pth', map_location=device))

pytorch_layers = [pytorch_model.classifier[0], pytorch_model.classifier[2], pytorch_model.classifier[4], pytorch_model.classifier[6]]

# Create the directory for weights and biases if it doesn't exist
create_directory('Archivio/500-300-100/batch440/weights_and_biases')

for i, layer in enumerate(pytorch_layers):
    layer_name = f'layer_{i+1}'
    
    # Extract and save weights
    weights = layer.weight.detach().numpy().T
    save_to_txt(weights, f'Archivio/500-300-100/batch440/weights_and_biases/{layer_name}_weights_500-300-100_batch440.txt')
    
    # Extract and save biases
    biases = layer.bias.detach().numpy().reshape(1, -1)
    save_to_txt(biases, f'Archivio/500-300-100/batch440/weights_and_biases/{layer_name}_biases_500-300-100_batch440.txt')

print("Weights and biases have been saved to their respective files.")
