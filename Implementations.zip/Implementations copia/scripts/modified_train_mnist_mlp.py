import numpy as np
import pandas as pd
import logging
import os
from itertools import product
from collections import namedtuple
from tensorflow.random import set_seed
from tensorflow.keras.layers import (
    Dense,
    BatchNormalization,
    Flatten,
)
from tensorflow.keras.initializers import GlorotUniform
from tensorflow.keras.models import Sequential, clone_model, save_model
from tensorflow.keras.datasets import mnist
from tensorflow.keras.utils import to_categorical
from quantized_network import QuantizedNeuralNetwork
from sys import stdout
from os import mkdir
from itertools import chain

NP_SEED = 1 
TF_SEED = 0
EPOCHS = 1
LAYER_WIDTHS = (500, 300, 100)
VALIDATION_SPLIT = 0.2 

# Write logs to file and to stdout. Overwrite previous log file.
fh = logging.FileHandler("../train_logs/model_training.log", mode="w+")
fh.setLevel(logging.INFO)
sh = logging.StreamHandler(stream=stdout)
sh.setLevel(logging.INFO)

# Only use the logger in this module.
logger = logging.getLogger(__name__)
logger.setLevel(level=logging.INFO)
logger.addHandler(fh)
logger.addHandler(sh)

# Make a directory to store serialized models.
timestamp = str(pd.Timestamp.now())
serialized_model_dir = f"../serialized_models/"

# Set the random seeds for numpy and tensorflow.
set_seed(0)
np.random.seed(0)

# Split training from testing
train, test = mnist.load_data()
train_size = train[0].shape[0]

# Split labels from data. Use one-hot encoding for labels.
X_train, y_train = train
X_test, y_test = test

# Use one-hot encoding for the labels.
num_classes = np.unique(y_train).shape[0]
y_train = to_categorical(y_train, num_classes)
y_test = to_categorical(y_test, num_classes)

# Build the model.
model = Sequential()
model.add(Flatten(input_shape=X_train[0].shape,))
for layer_idx, layer_width in enumerate(LAYER_WIDTHS):
    model.add(
        Dense(
            layer_width,
            activation="relu",
            kernel_initializer=GlorotUniform(),
            use_bias=True,
        )
    )
    model.add(BatchNormalization())
model.add(Dense(num_classes, activation="softmax"))
model.compile(
    optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"]
)

history = model.fit(
    X_train,
    y_train,
    batch_size=128,
    epochs=EPOCHS,
    verbose=True,
    validation_split=VALIDATION_SPLIT,
)

# Define base paths
data_dir = "/app/data"
serialized_models_dir = "/serialized_models"
train_logs_dir = "/train_logs"

# After training is complete, load weights and biases from txt files
# Iterate over batch sizes from 80 to 440 with a step of 40
for batch_size in range(80, 441, 40):
    dense_layer_count = 0
    for layer in model.layers:
        if isinstance(layer, Dense):
            dense_layer_count += 1
            layer_name = f'layer_{dense_layer_count}'
            # Load weights
            weights_file = os.path.join(data_dir, f'Archivio/500-300-100/batch{batch_size}/weights_and_biases/{layer_name}_weights_500-300-100_batch{batch_size}.txt')
            weights = np.loadtxt(weights_file)
            # Load biases
            biases_file = os.path.join(data_dir, f'Archivio/500-300-100/batch{batch_size}/weights_and_biases/{layer_name}_biases_500-300-100_batch{batch_size}.txt')
            biases = np.loadtxt(biases_file)
            # Set weights and biases for the current Dense layer
            layer.set_weights([weights, biases])
    print(f"Weights and biases have been updated from txt files for batch size {batch_size}.")
    # Evaluate the model with the new weights and biases
    analog_loss, analog_accuracy = model.evaluate(X_test, y_test, verbose=True)
    logger.info(f"Analog model test accuracy for batch size {batch_size} = {analog_accuracy:.2f}")
    model_path = os.path.join(serialized_models_dir, f"500-300-100/updated_500-300-100_batch{batch_size}")
    model.save(model_path, save_format='tf')
    print(f"Updated model for batch size {batch_size} saved to {model_path}")